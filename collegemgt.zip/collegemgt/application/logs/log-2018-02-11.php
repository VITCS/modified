<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2018-02-11 20:05:10 --> Severity: Notice  --> Only variable references should be returned by reference E:\xampp\htdocs\collegemgt\system\core\Common.php 257
DEBUG - 2018-02-11 20:05:10 --> Config Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:05:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:05:10 --> URI Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Router Class Initialized
DEBUG - 2018-02-11 20:05:10 --> No URI present. Default controller set.
DEBUG - 2018-02-11 20:05:10 --> Output Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Security Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Input Class Initialized
DEBUG - 2018-02-11 20:05:10 --> XSS Filtering completed
DEBUG - 2018-02-11 20:05:10 --> XSS Filtering completed
DEBUG - 2018-02-11 20:05:10 --> XSS Filtering completed
DEBUG - 2018-02-11 20:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-11 20:05:10 --> Language Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Loader Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: url_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: file_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: form_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: security_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: string_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: path_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: config_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: message_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: directory_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: download_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: multi_language_helper
DEBUG - 2018-02-11 20:05:10 --> Helper loaded: sms_helper
DEBUG - 2018-02-11 20:05:10 --> Session Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Session routines successfully run
DEBUG - 2018-02-11 20:05:10 --> Pagination Class Initialized
DEBUG - 2018-02-11 20:05:10 --> XML-RPC Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Form Validation Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Email Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Upload Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Encrypt Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Model Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Model Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Model Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Model Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Controller Class Initialized
DEBUG - 2018-02-11 20:05:10 --> Database Driver Class Initialized
ERROR - 2018-02-11 20:05:10 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user 'btppowerturboser'@'localhost' (using password: YES) E:\xampp\htdocs\collegemgt\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2018-02-11 20:05:10 --> Unable to connect to the database
DEBUG - 2018-02-11 20:05:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-02-11 20:06:10 --> Severity: Notice  --> Only variable references should be returned by reference E:\xampp\htdocs\collegemgt\system\core\Common.php 257
DEBUG - 2018-02-11 20:06:10 --> Config Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:06:10 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:06:10 --> URI Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Router Class Initialized
DEBUG - 2018-02-11 20:06:10 --> No URI present. Default controller set.
DEBUG - 2018-02-11 20:06:10 --> Output Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Security Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Input Class Initialized
DEBUG - 2018-02-11 20:06:10 --> XSS Filtering completed
DEBUG - 2018-02-11 20:06:10 --> XSS Filtering completed
DEBUG - 2018-02-11 20:06:10 --> XSS Filtering completed
DEBUG - 2018-02-11 20:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-11 20:06:10 --> Language Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Loader Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: url_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: file_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: form_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: security_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: string_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: path_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: config_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: message_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: inflector_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: directory_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: download_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: multi_language_helper
DEBUG - 2018-02-11 20:06:10 --> Helper loaded: sms_helper
DEBUG - 2018-02-11 20:06:10 --> Session Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Session routines successfully run
DEBUG - 2018-02-11 20:06:10 --> Pagination Class Initialized
DEBUG - 2018-02-11 20:06:10 --> XML-RPC Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Form Validation Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Email Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Upload Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Encrypt Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Model Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Model Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Model Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Model Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Controller Class Initialized
DEBUG - 2018-02-11 20:06:10 --> Database Driver Class Initialized
ERROR - 2018-02-11 20:06:10 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user 'btppowerturboser'@'localhost' (using password: YES) E:\xampp\htdocs\collegemgt\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2018-02-11 20:06:10 --> Unable to connect to the database
DEBUG - 2018-02-11 20:06:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2018-02-11 20:11:37 --> Severity: Notice  --> Only variable references should be returned by reference E:\xampp\htdocs\collegemgt\system\core\Common.php 257
DEBUG - 2018-02-11 20:11:37 --> Config Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:11:37 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:11:37 --> URI Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Router Class Initialized
DEBUG - 2018-02-11 20:11:37 --> No URI present. Default controller set.
DEBUG - 2018-02-11 20:11:37 --> Output Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Security Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Input Class Initialized
DEBUG - 2018-02-11 20:11:37 --> XSS Filtering completed
DEBUG - 2018-02-11 20:11:37 --> XSS Filtering completed
DEBUG - 2018-02-11 20:11:37 --> XSS Filtering completed
DEBUG - 2018-02-11 20:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-11 20:11:37 --> Language Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Loader Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: url_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: file_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: form_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: security_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: string_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: path_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: config_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: message_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: inflector_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: directory_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: download_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: multi_language_helper
DEBUG - 2018-02-11 20:11:37 --> Helper loaded: sms_helper
DEBUG - 2018-02-11 20:11:37 --> Session Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Session routines successfully run
DEBUG - 2018-02-11 20:11:37 --> Pagination Class Initialized
DEBUG - 2018-02-11 20:11:37 --> XML-RPC Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Form Validation Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Email Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Upload Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Encrypt Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Model Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Model Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Model Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Model Class Initialized
DEBUG - 2018-02-11 20:11:37 --> Controller Class Initialized
ERROR - 2018-02-11 20:11:37 --> Severity: Warning  --> Declaration of CI_DB_mysqli_driver::_update($table, $values, $where, $orderby = Array, $limit = false) should be compatible with CI_DB_driver::_update($table, $values) E:\xampp\htdocs\collegemgt\system\database\drivers\mysqli\mysqli_driver.php 772
ERROR - 2018-02-11 20:11:37 --> Severity: Warning  --> Declaration of CI_DB_mysqli_driver::_close($conn_id) should be compatible with CI_DB_driver::_close() E:\xampp\htdocs\collegemgt\system\database\drivers\mysqli\mysqli_driver.php 0
INFO  - 2018-02-11 20:11:37 --> Database Driver Class Initialized
ERROR - 2018-02-11 20:11:37 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_driver::$autoinit E:\xampp\htdocs\collegemgt\system\database\DB.php 146
ERROR - 2018-02-11 20:17:21 --> Severity: Notice  --> Only variable references should be returned by reference E:\xampp\htdocs\collegemgt\system\core\Common.php 257
DEBUG - 2018-02-11 20:17:21 --> Config Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Hooks Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Utf8 Class Initialized
DEBUG - 2018-02-11 20:17:21 --> UTF-8 Support Enabled
DEBUG - 2018-02-11 20:17:21 --> URI Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Router Class Initialized
DEBUG - 2018-02-11 20:17:21 --> No URI present. Default controller set.
DEBUG - 2018-02-11 20:17:21 --> Output Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Security Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Input Class Initialized
DEBUG - 2018-02-11 20:17:21 --> XSS Filtering completed
DEBUG - 2018-02-11 20:17:21 --> XSS Filtering completed
DEBUG - 2018-02-11 20:17:21 --> XSS Filtering completed
DEBUG - 2018-02-11 20:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2018-02-11 20:17:21 --> Language Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Loader Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: url_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: file_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: form_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: security_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: string_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: path_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: config_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: message_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: inflector_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: directory_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: download_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: multi_language_helper
DEBUG - 2018-02-11 20:17:21 --> Helper loaded: sms_helper
DEBUG - 2018-02-11 20:17:21 --> Session Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Session routines successfully run
DEBUG - 2018-02-11 20:17:21 --> Pagination Class Initialized
DEBUG - 2018-02-11 20:17:21 --> XML-RPC Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Form Validation Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Email Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Upload Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Encrypt Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Model Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Model Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Model Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Model Class Initialized
DEBUG - 2018-02-11 20:17:21 --> Controller Class Initialized
ERROR - 2018-02-11 20:17:21 --> Severity: Warning  --> Declaration of CI_DB_mysqli_driver::_update($table, $values, $where, $orderby = Array, $limit = false) should be compatible with CI_DB_driver::_update($table, $values) E:\xampp\htdocs\collegemgt\system\database\drivers\mysqli\mysqli_driver.php 772
ERROR - 2018-02-11 20:17:21 --> Severity: Warning  --> Declaration of CI_DB_mysqli_driver::_close($conn_id) should be compatible with CI_DB_driver::_close() E:\xampp\htdocs\collegemgt\system\database\drivers\mysqli\mysqli_driver.php 0
INFO  - 2018-02-11 20:17:21 --> Database Driver Class Initialized
ERROR - 2018-02-11 20:17:21 --> Severity: Notice  --> Undefined property: CI_DB_mysqli_driver::$autoinit E:\xampp\htdocs\collegemgt\system\database\DB.php 146
